from django import forms
from .models import FnwModel

class FnwForm(forms.ModelForm):
    URL = forms.CharField(max_length=1000,widget=forms.TextInput(
        attrs={
            'class':'form-control',
        }
    ))
    Article = forms.CharField(max_length=1000,widget=forms.TextInput(
        attrs={
            'class':'form-control',
            'size':'40',
        }
    ))
    class Meta:
        model = FnwModel
        fields = [
            'URL',
            'Article'
        ]