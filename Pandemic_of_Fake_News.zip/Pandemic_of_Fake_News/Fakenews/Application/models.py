from django.db import models

# Create your models here.
class FnwModel(models.Model):
    URL = models.CharField(max_length=1000)
    Article = models.CharField(max_length=1000)