from django.shortcuts import render
from .models import FnwModel
from .forms import FnwForm
from Fakenewsdetector import mainfunc

# Create your views here.
def Application(request):
    form = FnwForm(request.POST or None)
    context = {}
    if request.method == 'POST':
        if form.is_valid():
            a = form.cleaned_data.get('Article')
            u = form.cleaned_data.get('URL')   # got the sentence
            textAns = mainfunc(a,u)
            context['text'] = textAns
        else:
            form = FnwForm()
    
    context['form'] = form
    return render(request, 'final_app.html', context=context)
