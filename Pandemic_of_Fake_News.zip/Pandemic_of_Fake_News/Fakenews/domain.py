from urllib.parse import urlparse
def urlchk(url):
    domain=urlparse(url).netloc
    print(domain)
    if domain in open('Fake_URL.csv').read():
        return 1
    elif domain in open('True_URL.csv').read():
        return 2