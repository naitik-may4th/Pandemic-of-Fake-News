from textblob import TextBlob
def splchk(text):
    p = TextBlob(text)
    data=p.correct()
    return data